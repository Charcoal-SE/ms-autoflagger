from __future__ import print_function
import boto3
import os
import json
import requests
from urllib.parse import urlparse, parse_qs
import sys

client = boto3.client('dynamodb')

def lambda_handler(event, context):
    if event["resource"] == "/auth":
        return run_auth(event)
    elif event["resource"] == "/auth/complete":
        return completed_auth(event)
    else:
        username="foosername"
        token="bartoken"
        item = {
            "username" : {
                "S" : username
            },
            "api_token" : {
                "S" : token
            }
        }
        resp = "" #client.put_item(TableName="autoflagger",Item=item)
        print(resp)
        return {
            "isBase64Encoded": False,
            "statusCode": 200,
            "headers": {},
            "body": event["resource"]
        }

def completed_auth(event):
    client_id = os.environ['CLIENT_ID']
    client_secret = os.environ['CLIENT_SECRET']
    code = event["queryStringParameters"]["code"]
    ctx = event["requestContext"]
    proto = "https"# event["headers"]["X-Forwarded-Proto"]
    redirect_uri = proto + "://" + ctx["domainName"] + ctx["path"]
    # return {
    #         "isBase64Encoded": False,
    #         "statusCode": 200,
    #         "headers": {"Content-Type":"text/plain"},
    #         "body": "AHHHH!\n" + code
    #     }
    r = requests.post("https://stackoverflow.com/oauth/access_token",
                        data={
                        "client_id": client_id,
                        "code": code,
                        "client_secret": client_secret,
                        "redirect_uri": redirect_uri
                        })
    if r.status_code == 200:
        qs = parse_qs(r.text)
        access_token = qs["access_token"][0]
        expires = qs["expires"][0]
        api_key = os.environ['API_KEY']
        me = requests.get("https://api.stackexchange.com/2.2/me/associated?filter=!ms3dUCONeu&key="+str(api_key)+"&access_token="+str(access_token)+"&pagesize=1&page=1")
        if "error_id" in me.json():
            return {
                "isBase64Encoded": False,
                "statusCode": 200,
                "headers": {"Content-Type":"text/plain"},
                "body": "SE OAuth Failed, API Issues!\n" + me.text + "\n" + "https://api.stackexchange.com/2.2/me/associated?filter=!ms3dUCONeu&key="+str(api_key)+"&access_token="+str(access_token[0])+"&pagesize=1&page=1"
            }
        else:
            id = me.json()["items"][0]["account_id"]
            item = {
                "account_id" : {
                    "N" : str(id)
                },
                "access_token" : {
                    "S" : access_token
                },
                "expiration_date" : {
                    "S" : expires
                }
            }
            client.put_item(TableName="autoflagger",Item=item)
            return {
                "isBase64Encoded": False,
                "statusCode": 200,
                "headers": {"Content-Type":"text/plain"},
                "body": "SE OAuth Sucessful!"
            }
    else:
        return {
            "isBase64Encoded": False,
            "statusCode": 200,
            "headers": {"Content-Type":"text/plain"},
            "body": "SE OAuth Failed :(\n" + r.text
        }

def run_auth(event):
    client_id = os.environ['CLIENT_ID']
    ctx = event["requestContext"]
    proto = "https"# event["headers"]["X-Forwarded-Proto"]
    redirect_uri = proto + "://" + ctx["domainName"] + ctx["path"] + "/complete"
    redirect_uri = "https://btmi925fb2.execute-api.us-east-1.amazonaws.com/default/auth/complete"
    qstring = "?redirect_uri=" + redirect_uri + "&client_id=" + client_id + "&state=" + redirect_uri
    return {
        "isBase64Encoded": False,
        "statusCode": 302,
        "headers": {"Location": "https://stackoverflow.com/oauth" + qstring},
        "body": "Redirecting you to Stack Exchange OAuth"
    }
